# MyCima Website

This is a simple movie website project developed by Kyle.

## Contact

For any inquiries or contributions, please contact Kyle via email at kyle.dev@mail.ru.
